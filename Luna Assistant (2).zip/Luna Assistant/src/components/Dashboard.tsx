import React, { useState } from 'react';
import Sidebar from './Sidebar';
import VoiceInterface from './VoiceInterface';
import ChatInterface from './ChatInterface';
import Calendar from './Calendar';
import Settings from './Settings';
import ImageGenerator from './ImageGenerator';

interface DashboardProps {
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onLogout }) => {
  const [activeTab, setActiveTab] = useState('voice');

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'voice':
        return <VoiceInterface />;
      case 'chat':
        return <ChatInterface />;
      case 'calendar':
        return <Calendar />;
      case 'images':
        return <ImageGenerator />;
      case 'settings':
        return <Settings />;
      default:
        return <VoiceInterface />;
    }
  };

  return (
    <div className="min-h-screen flex">
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab}
        onLogout={onLogout}
      />
      <main className="flex-1 p-6">
        {renderActiveComponent()}
      </main>
    </div>
  );
};

export default Dashboard;