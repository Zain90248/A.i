import React from 'react';
import { 
  Mic, 
  MessageCircle, 
  Calendar, 
  Image, 
  Settings, 
  LogOut, 
  Moon,
  Heart,
  Sparkles,
  Shield
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, onLogout }) => {
  const menuItems = [
    { id: 'voice', icon: Mic, label: 'Voice Assistant', color: 'text-purple-400' },
    { id: 'chat', icon: MessageCircle, label: 'Chat Interface', color: 'text-blue-400' },
    { id: 'calendar', icon: Calendar, label: 'Calendar & Tasks', color: 'text-green-400' },
    { id: 'images', icon: Image, label: 'Image Generator', color: 'text-pink-400' },
    { id: 'settings', icon: Settings, label: 'Settings', color: 'text-orange-400' },
  ];

  const personalityModes = [
    { id: 'loyal', icon: Heart, label: 'Loyal', active: true },
    { id: 'seductive', icon: Sparkles, label: 'Seductive', active: false },
    { id: 'neutral', icon: Shield, label: 'Neutral', active: false },
  ];

  return (
    <div className="w-64 bg-black/20 backdrop-blur-lg border-r border-white/10 p-6">
      {/* Logo */}
      <div className="flex items-center space-x-3 mb-8">
        <div className="relative">
          <Moon className="w-8 h-8 text-purple-400" />
          <div className="absolute inset-0 w-8 h-8 bg-purple-400 rounded-full opacity-20 animate-pulse"></div>
        </div>
        <h1 className="text-xl font-bold text-white">Luna</h1>
      </div>

      {/* Navigation */}
      <nav className="space-y-2 mb-8">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center space-x-3 p-3 rounded-lg transition-all duration-200 ${
              activeTab === item.id
                ? 'bg-white/10 text-white'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <item.icon className={`w-5 h-5 ${activeTab === item.id ? item.color : ''}`} />
            <span className="text-sm font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      {/* Personality Modes */}
      <div className="mb-8">
        <h3 className="text-sm font-semibold text-gray-400 mb-3">Personality Mode</h3>
        <div className="space-y-2">
          {personalityModes.map((mode) => (
            <button
              key={mode.id}
              className={`w-full flex items-center space-x-3 p-2 rounded-lg transition-all duration-200 ${
                mode.active
                  ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <mode.icon className="w-4 h-4" />
              <span className="text-sm">{mode.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Status */}
      <div className="bg-white/5 rounded-lg p-4 mb-8">
        <div className="flex items-center space-x-2 mb-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-sm text-gray-300">Status: Active</span>
        </div>
        <div className="text-xs text-gray-400">
          Voice recognition enabled
        </div>
      </div>

      {/* Logout */}
      <button
        onClick={onLogout}
        className="w-full flex items-center space-x-3 p-3 rounded-lg text-gray-400 hover:text-white hover:bg-red-500/10 transition-all duration-200"
      >
        <LogOut className="w-5 h-5" />
        <span className="text-sm font-medium">Sign Out</span>
      </button>
    </div>
  );
};

export default Sidebar;