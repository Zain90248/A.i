import React, { useState } from 'react';
import { Plus, CheckCircle, Clock, AlertCircle } from 'lucide-react';

const Calendar: React.FC = () => {
  const [tasks, setTasks] = useState([
    { id: 1, title: "Team meeting with Luna", time: "9:00 AM", completed: false, priority: "high" },
    { id: 2, title: "Review project documentation", time: "11:30 AM", completed: true, priority: "medium" },
    { id: 3, title: "Lunch with client", time: "1:00 PM", completed: false, priority: "high" },
    { id: 4, title: "Code review session", time: "3:30 PM", completed: false, priority: "low" },
  ]);

  const [newTask, setNewTask] = useState('');

  const addTask = () => {
    if (!newTask.trim()) return;
    
    const task = {
      id: tasks.length + 1,
      title: newTask,
      time: "TBD",
      completed: false,
      priority: "medium"
    };
    
    setTasks([...tasks, task]);
    setNewTask('');
  };

  const toggleTask = (id: number) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'border-red-400';
      case 'medium': return 'border-yellow-400';
      case 'low': return 'border-green-400';
      default: return 'border-gray-400';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return <AlertCircle className="w-4 h-4 text-red-400" />;
      case 'medium': return <Clock className="w-4 h-4 text-yellow-400" />;
      case 'low': return <CheckCircle className="w-4 h-4 text-green-400" />;
      default: return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-white">Calendar & Tasks</h1>
        <p className="text-gray-400">Manage your schedule with Luna's intelligent assistance</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{tasks.filter(t => !t.completed).length}</p>
              <p className="text-gray-400 text-sm">Pending Tasks</p>
            </div>
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{tasks.filter(t => t.completed).length}</p>
              <p className="text-gray-400 text-sm">Completed</p>
            </div>
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{tasks.filter(t => t.priority === 'high' && !t.completed).length}</p>
              <p className="text-gray-400 text-sm">High Priority</p>
            </div>
          </div>
        </div>
      </div>

      {/* Add New Task */}
      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
        <h3 className="text-lg font-semibold text-white mb-4">Add New Task</h3>
        <div className="flex space-x-4">
          <input
            type="text"
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTask()}
            placeholder="Enter a new task..."
            className="flex-1 bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400"
          />
          <button
            onClick={addTask}
            className="bg-purple-500 hover:bg-purple-600 text-white p-3 rounded-lg transition-colors duration-200"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Tasks List */}
      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
        <h3 className="text-lg font-semibold text-white mb-6">Today's Schedule</h3>
        <div className="space-y-4">
          {tasks.map((task) => (
            <div
              key={task.id}
              className={`flex items-center space-x-4 p-4 rounded-lg border-l-4 ${
                task.completed ? 'bg-white/5' : 'bg-white/10'
              } ${getPriorityColor(task.priority)}`}
            >
              <button
                onClick={() => toggleTask(task.id)}
                className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors duration-200 ${
                  task.completed
                    ? 'bg-green-500 border-green-500'
                    : 'border-gray-400 hover:border-purple-400'
                }`}
              >
                {task.completed && <CheckCircle className="w-4 h-4 text-white" />}
              </button>

              <div className="flex-1">
                <h4 className={`font-medium ${task.completed ? 'text-gray-400 line-through' : 'text-white'}`}>
                  {task.title}
                </h4>
                <p className="text-sm text-gray-400">{task.time}</p>
              </div>

              <div className="flex items-center space-x-2">
                {getPriorityIcon(task.priority)}
                <span className="text-sm text-gray-400 capitalize">{task.priority}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Voice Commands */}
      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
        <h3 className="text-lg font-semibold text-white mb-4">Voice Commands</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            '"Hey Luna, add meeting at 2 PM"',
            '"Hey Luna, mark task as complete"',
            '"Hey Luna, what\'s my schedule today?"',
            '"Hey Luna, set reminder for tomorrow"'
          ].map((command, index) => (
            <div key={index} className="bg-white/5 rounded-lg p-3">
              <p className="text-sm text-gray-300 font-mono">{command}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Calendar;