import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Volume2, Pause, Play, Brain } from 'lucide-react';
import { openAIService } from '../services/openai';

const VoiceInterface: React.FC = () => {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [currentMood, setCurrentMood] = useState('calm');
  const [voiceLevel, setVoiceLevel] = useState(0);
  const [lastCommand, setLastCommand] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [personality, setPersonality] = useState('loyal');

  useEffect(() => {
    // Simulate voice level animation
    if (isListening) {
      const interval = setInterval(() => {
        setVoiceLevel(Math.random() * 100);
      }, 100);
      return () => clearInterval(interval);
    }
  }, [isListening]);

  const toggleListening = () => {
    if (isListening) {
      setIsListening(false);
      setVoiceLevel(0);
    } else {
      setIsListening(true);
      // Simulate voice recognition
      setTimeout(() => {
        simulateVoiceCommand();
      }, 3000);
    }
  };

  const simulateVoiceCommand = async () => {
    const commands = [
      "Hey Luna, what's the weather today?",
      "Luna, set a reminder for my meeting",
      "Hey Luna, tell me a joke",
      "Luna, how are you feeling?",
      "Hey Luna, generate an image of a sunset"
    ];
    
    const randomCommand = commands[Math.floor(Math.random() * commands.length)];
    setLastCommand(randomCommand);
    setIsListening(false);
    setIsProcessing(true);

    try {
      // Process the command with AI
      const response = await openAIService.generateChatResponse([
        { role: 'user', content: randomCommand }
      ], personality);
      
      // Simulate speaking the response
      setIsSpeaking(true);
      setTimeout(() => {
        setIsSpeaking(false);
        setIsProcessing(false);
      }, 3000);
      
    } catch (error) {
      console.error('Error processing voice command:', error);
      setIsProcessing(false);
    }
  };

  const toggleSpeaking = () => {
    setIsSpeaking(!isSpeaking);
  };

  const moodColors = {
    calm: 'from-blue-500 to-cyan-500',
    happy: 'from-yellow-400 to-orange-500',
    focused: 'from-purple-500 to-pink-500',
    excited: 'from-red-500 to-pink-500',
  };

  const getStatusText = () => {
    if (isProcessing) return 'Processing...';
    if (isSpeaking) return 'Speaking...';
    if (isListening) return 'Listening...';
    return 'Ready to Listen';
  };

  const getStatusDescription = () => {
    if (isProcessing) return 'Luna is thinking about your request';
    if (isSpeaking) return 'Luna is responding to your command';
    if (isListening) return 'Speak now, I\'m listening';
    return 'Click the microphone or say "Hey Luna"';
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-white">Voice Assistant</h1>
        <p className="text-gray-400">Say "Hey Luna" to activate or click the button below</p>
        
        {/* Personality Selector */}
        <div className="flex justify-center">
          <select
            value={personality}
            onChange={(e) => setPersonality(e.target.value)}
            className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-purple-400"
          >
            <option value="loyal">Loyal Mode</option>
            <option value="seductive">Seductive Mode</option>
            <option value="neutral">Neutral Mode</option>
          </select>
        </div>
      </div>

      {/* Main Voice Interface */}
      <div className="bg-white/5 backdrop-blur-lg rounded-3xl p-8 border border-white/10">
        <div className="text-center space-y-8">
          
          {/* RGB Mood Ring */}
          <div className="relative mx-auto w-64 h-64">
            <div className={`absolute inset-0 rounded-full bg-gradient-to-r ${moodColors[currentMood]} opacity-20 animate-pulse`}></div>
            <div className={`absolute inset-4 rounded-full bg-gradient-to-r ${moodColors[currentMood]} opacity-40`}></div>
            <div className={`absolute inset-8 rounded-full bg-gradient-to-r ${moodColors[currentMood]} opacity-60`}></div>
            
            {/* Voice Visualizer */}
            {(isListening || isProcessing) && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="flex space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <div
                      key={i}
                      className="w-2 bg-white rounded-full animate-pulse"
                      style={{
                        height: `${20 + (voiceLevel * 0.6)}px`,
                        animationDelay: `${i * 100}ms`
                      }}
                    ></div>
                  ))}
                </div>
              </div>
            )}

            {/* Processing Indicator */}
            {isProcessing && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Brain className="w-12 h-12 text-purple-400 animate-pulse" />
              </div>
            )}
            
            {/* Center Button */}
            <button
              onClick={toggleListening}
              disabled={isProcessing}
              className={`absolute inset-16 rounded-full flex items-center justify-center transition-all duration-300 transform hover:scale-105 disabled:cursor-not-allowed ${
                isListening 
                  ? 'bg-red-500 hover:bg-red-600 shadow-lg shadow-red-500/25' 
                  : isProcessing
                  ? 'bg-yellow-500 shadow-lg shadow-yellow-500/25'
                  : 'bg-purple-500 hover:bg-purple-600 shadow-lg shadow-purple-500/25'
              }`}
            >
              {isProcessing ? (
                <Brain className="w-8 h-8 text-white animate-pulse" />
              ) : isListening ? (
                <MicOff className="w-8 h-8 text-white" />
              ) : (
                <Mic className="w-8 h-8 text-white" />
              )}
            </button>
          </div>

          {/* Status */}
          <div className="space-y-2">
            <h3 className="text-xl font-semibold text-white">
              {getStatusText()}
            </h3>
            <p className="text-gray-400">
              {getStatusDescription()}
            </p>
            {lastCommand && (
              <p className="text-sm text-purple-400 bg-purple-500/20 rounded-lg px-4 py-2 inline-block">
                Last command: "{lastCommand}"
              </p>
            )}
          </div>

          {/* Quick Actions */}
          <div className="flex justify-center space-x-4">
            <button
              onClick={toggleSpeaking}
              disabled={isProcessing}
              className={`flex items-center space-x-2 px-6 py-3 rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed ${
                isSpeaking
                  ? 'bg-orange-500 hover:bg-orange-600 text-white'
                  : 'bg-white/10 hover:bg-white/20 text-gray-300'
              }`}
            >
              {isSpeaking ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              <span>{isSpeaking ? 'Pause' : 'Test Voice'}</span>
            </button>
            
            <button className="flex items-center space-x-2 px-6 py-3 bg-white/10 hover:bg-white/20 rounded-lg transition-all duration-200 text-gray-300">
              <Volume2 className="w-5 h-5" />
              <span>Volume</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mood Selector */}
      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
        <h3 className="text-lg font-semibold text-white mb-4">Current Mood Detection</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Object.entries(moodColors).map(([mood, gradient]) => (
            <button
              key={mood}
              onClick={() => setCurrentMood(mood)}
              className={`p-4 rounded-lg transition-all duration-200 ${
                currentMood === mood
                  ? 'bg-white/20 border-2 border-white/30'
                  : 'bg-white/5 hover:bg-white/10 border-2 border-transparent'
              }`}
            >
              <div className={`w-8 h-8 rounded-full bg-gradient-to-r ${gradient} mx-auto mb-2`}></div>
              <span className="text-sm text-gray-300 capitalize">{mood}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Voice Commands Examples */}
      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
        <h3 className="text-lg font-semibold text-white mb-4">Voice Commands</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            '"Hey Luna, what\'s the weather today?"',
            '"Hey Luna, set a reminder for my meeting"',
            '"Hey Luna, tell me a joke"',
            '"Hey Luna, generate an image of a sunset"',
            '"Hey Luna, how are you feeling?"',
            '"Hey Luna, switch to seductive mode"'
          ].map((command, index) => (
            <div key={index} className="bg-white/5 rounded-lg p-3">
              <p className="text-sm text-gray-300 font-mono">{command}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VoiceInterface;