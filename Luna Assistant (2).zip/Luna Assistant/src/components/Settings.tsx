import React, { useState } from 'react';
import { 
  User, 
  Mic, 
  Volume2, 
  Palette, 
  Shield, 
  Globe, 
  Moon,
  Heart,
  Sparkles,
  Save
} from 'lucide-react';

const Settings: React.FC = () => {
  const [settings, setSettings] = useState({
    name: 'Luna',
    voiceType: 'feminine',
    personality: 'loyal',
    language: 'english',
    voiceSpeed: 1.0,
    volume: 0.8,
    wakeWord: 'Hey Luna',
    theme: 'dark',
    notifications: true,
    autoResponse: true
  });

  const updateSetting = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const personalityOptions = [
    { value: 'loyal', label: 'Loyal', icon: Heart, desc: 'Faithful and supportive companion' },
    { value: 'seductive', label: 'Seductive', icon: Sparkles, desc: 'Charming and playful personality' },
    { value: 'neutral', label: 'Neutral', icon: Shield, desc: 'Professional and balanced approach' }
  ];

  const languages = [
    'English', 'Spanish', 'French', 'German', 'Chinese', 'Japanese', 'Korean', 'Portuguese'
  ];

  const voiceTypes = [
    'Feminine (Soft)', 'Feminine (Strong)', 'Neutral', 'Masculine'
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-white">Settings</h1>
        <p className="text-gray-400">Customize Luna's personality, voice, and behavior</p>
      </div>

      {/* Personal Settings */}
      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
        <div className="flex items-center space-x-3 mb-6">
          <User className="w-6 h-6 text-purple-400" />
          <h2 className="text-xl font-semibold text-white">Personal Settings</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Assistant Name
            </label>
            <input
              type="text"
              value={settings.name}
              onChange={(e) => updateSetting('name', e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Wake Word
            </label>
            <input
              type="text"
              value={settings.wakeWord}
              onChange={(e) => updateSetting('wakeWord', e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400"
            />
          </div>
        </div>
      </div>

      {/* Personality Settings */}
      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
        <div className="flex items-center space-x-3 mb-6">
          <Heart className="w-6 h-6 text-pink-400" />
          <h2 className="text-xl font-semibold text-white">Personality Mode</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {personalityOptions.map((option) => (
            <button
              key={option.value}
              onClick={() => updateSetting('personality', option.value)}
              className={`p-6 rounded-lg border-2 transition-all duration-200 text-left ${
                settings.personality === option.value
                  ? 'border-purple-400 bg-purple-500/20'
                  : 'border-white/20 bg-white/5 hover:bg-white/10'
              }`}
            >
              <div className="flex items-center space-x-3 mb-3">
                <option.icon className={`w-6 h-6 ${
                  settings.personality === option.value ? 'text-purple-400' : 'text-gray-400'
                }`} />
                <h3 className="font-semibold text-white">{option.label}</h3>
              </div>
              <p className="text-sm text-gray-400">{option.desc}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Voice Settings */}
      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
        <div className="flex items-center space-x-3 mb-6">
          <Mic className="w-6 h-6 text-blue-400" />
          <h2 className="text-xl font-semibold text-white">Voice Settings</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Voice Type
            </label>
            <select
              value={settings.voiceType}
              onChange={(e) => updateSetting('voiceType', e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400"
            >
              {voiceTypes.map((type) => (
                <option key={type} value={type.toLowerCase().replace(/[()]/g, '').replace(' ', '_')}>
                  {type}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Speech Speed: {settings.voiceSpeed}x
            </label>
            <input
              type="range"
              min="0.5"
              max="2.0"
              step="0.1"
              value={settings.voiceSpeed}
              onChange={(e) => updateSetting('voiceSpeed', parseFloat(e.target.value))}
              className="w-full"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Volume: {Math.round(settings.volume * 100)}%
            </label>
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={settings.volume}
              onChange={(e) => updateSetting('volume', parseFloat(e.target.value))}
              className="w-full"
            />
          </div>
        </div>
      </div>

      {/* Language Settings */}
      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
        <div className="flex items-center space-x-3 mb-6">
          <Globe className="w-6 h-6 text-green-400" />
          <h2 className="text-xl font-semibold text-white">Language & Regional</h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {languages.map((lang) => (
            <button
              key={lang}
              onClick={() => updateSetting('language', lang.toLowerCase())}
              className={`p-4 rounded-lg border transition-all duration-200 ${
                settings.language === lang.toLowerCase()
                  ? 'border-green-400 bg-green-500/20 text-green-400'
                  : 'border-white/20 bg-white/5 text-gray-300 hover:bg-white/10'
              }`}
            >
              {lang}
            </button>
          ))}
        </div>
      </div>

      {/* Appearance Settings */}
      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
        <div className="flex items-center space-x-3 mb-6">
          <Palette className="w-6 h-6 text-purple-400" />
          <h2 className="text-xl font-semibold text-white">Appearance</h2>
        </div>

        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-white font-medium">Dark Theme</h3>
              <p className="text-sm text-gray-400">Use dark mode interface</p>
            </div>
            <button
              onClick={() => updateSetting('theme', settings.theme === 'dark' ? 'light' : 'dark')}
              className={`relative w-12 h-6 rounded-full transition-colors duration-200 ${
                settings.theme === 'dark' ? 'bg-purple-500' : 'bg-gray-400'
              }`}
            >
              <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform duration-200 ${
                settings.theme === 'dark' ? 'translate-x-7' : 'translate-x-1'
              }`}></div>
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-white font-medium">Notifications</h3>
              <p className="text-sm text-gray-400">Receive voice and visual notifications</p>
            </div>
            <button
              onClick={() => updateSetting('notifications', !settings.notifications)}
              className={`relative w-12 h-6 rounded-full transition-colors duration-200 ${
                settings.notifications ? 'bg-purple-500' : 'bg-gray-400'
              }`}
            >
              <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform duration-200 ${
                settings.notifications ? 'translate-x-7' : 'translate-x-1'
              }`}></div>
            </button>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <div className="flex justify-center">
        <button className="flex items-center space-x-3 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-8 py-4 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105">
          <Save className="w-5 h-5" />
          <span>Save All Settings</span>
        </button>
      </div>
    </div>
  );
};

export default Settings;