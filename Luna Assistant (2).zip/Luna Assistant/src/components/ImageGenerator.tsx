import React, { useState } from 'react';
import { Wand2, Download, RefreshCw, Sparkles, Loader2 } from 'lucide-react';
import { openAIService } from '../services/openai';

interface GeneratedImage {
  id: number;
  url: string;
  prompt: string;
  style: string;
  timestamp: Date;
}

const ImageGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('realistic');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([
    {
      id: 1,
      url: 'https://images.pexels.com/photos/3616764/pexels-photo-3616764.jpeg?auto=compress&cs=tinysrgb&w=400',
      prompt: 'Futuristic AI assistant in a neon-lit room',
      style: 'Cyberpunk',
      timestamp: new Date()
    },
    {
      id: 2,
      url: 'https://images.pexels.com/photos/2387793/pexels-photo-2387793.jpeg?auto=compress&cs=tinysrgb&w=400',
      prompt: 'Abstract digital art with purple and blue gradients',
      style: 'Abstract',
      timestamp: new Date()
    },
    {
      id: 3,
      url: 'https://images.pexels.com/photos/1097491/pexels-photo-1097491.jpeg?auto=compress&cs=tinysrgb&w=400',
      prompt: 'Serene landscape with mountains and aurora',
      style: 'Realistic',
      timestamp: new Date()
    }
  ]);

  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;
    
    setIsGenerating(true);
    
    try {
      const imageUrl = await openAIService.generateImage(prompt, selectedStyle);
      
      if (imageUrl) {
        const newImage: GeneratedImage = {
          id: Date.now(),
          url: imageUrl,
          prompt: prompt,
          style: selectedStyle,
          timestamp: new Date()
        };
        
        setGeneratedImages(prev => [newImage, ...prev]);
        setPrompt('');
      }
    } catch (error) {
      console.error('Error generating image:', error);
      // You could add a toast notification here
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = async (imageUrl: string, prompt: string) => {
    try {
      const response = await fetch(imageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `luna-generated-${prompt.slice(0, 30).replace(/[^a-zA-Z0-9]/g, '-')}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading image:', error);
    }
  };

  const handleRegenerate = (originalPrompt: string, style: string) => {
    setPrompt(originalPrompt);
    setSelectedStyle(style);
  };

  const styles = [
    { value: 'realistic', label: 'Realistic' },
    { value: 'anime', label: 'Anime' },
    { value: 'digital-art', label: 'Digital Art' },
    { value: 'oil-painting', label: 'Oil Painting' },
    { value: 'watercolor', label: 'Watercolor' },
    { value: 'cyberpunk', label: 'Cyberpunk' },
    { value: 'fantasy', label: 'Fantasy' },
    { value: 'abstract', label: 'Abstract' }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-white">AI Image Generator</h1>
        <p className="text-gray-400">Create stunning images with Luna's advanced AI capabilities</p>
      </div>

      {/* Generation Interface */}
      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Describe what you want to create
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g., A futuristic city at sunset with flying cars and neon lights..."
              className="w-full h-24 bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 resize-none"
              disabled={isGenerating}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-3">
              Art Style
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {styles.map((style) => (
                <button
                  key={style.value}
                  onClick={() => setSelectedStyle(style.value)}
                  disabled={isGenerating}
                  className={`p-3 rounded-lg text-sm transition-all duration-200 ${
                    selectedStyle === style.value
                      ? 'bg-purple-500/30 border-2 border-purple-400 text-white'
                      : 'bg-white/10 hover:bg-purple-500/20 border border-white/20 hover:border-purple-400 text-gray-300 hover:text-white'
                  } disabled:opacity-50 disabled:cursor-not-allowed`}
                >
                  {style.label}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim()}
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 disabled:from-gray-500 disabled:to-gray-600 disabled:cursor-not-allowed text-white py-4 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center space-x-2"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Generating Image...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-5 h-5" />
                <span>Generate Image</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Generated Images Gallery */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-white">Generated Images</h2>
          <div className="flex items-center space-x-2 text-gray-400">
            <Sparkles className="w-5 h-5" />
            <span>{generatedImages.length} images created</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {generatedImages.map((image) => (
            <div key={image.id} className="bg-white/5 backdrop-blur-lg rounded-xl border border-white/10 overflow-hidden group">
              <div className="relative aspect-square">
                <img
                  src={image.url}
                  alt={image.prompt}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center space-x-4">
                  <button 
                    onClick={() => handleDownload(image.url, image.prompt)}
                    className="bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-lg p-3 text-white transition-colors"
                    title="Download Image"
                  >
                    <Download className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => handleRegenerate(image.prompt, image.style.toLowerCase())}
                    className="bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-lg p-3 text-white transition-colors"
                    title="Regenerate Similar"
                  >
                    <RefreshCw className="w-5 h-5" />
                  </button>
                </div>
              </div>
              <div className="p-4">
                <p className="text-white font-medium mb-2 line-clamp-2">{image.prompt}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-purple-400 bg-purple-500/20 px-2 py-1 rounded-full">
                    {image.style}
                  </span>
                  <span className="text-xs text-gray-400">
                    {image.timestamp.toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Voice Commands */}
      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10">
        <h3 className="text-lg font-semibold text-white mb-4">Voice Generation Commands</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            '"Hey Luna, generate a sunset landscape"',
            '"Hey Luna, create anime style character"',
            '"Hey Luna, make abstract digital art"',
            '"Hey Luna, generate cyberpunk city scene"'
          ].map((command, index) => (
            <div key={index} className="bg-white/5 rounded-lg p-3">
              <p className="text-sm text-gray-300 font-mono">{command}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ImageGenerator;