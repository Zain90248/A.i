import React, { useState, useRef, useEffect } from 'react';
import { Send, Heart, Brain, Sparkles, Loader2 } from 'lucide-react';
import { openAIService } from '../services/openai';

interface Message {
  id: number;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  emotion?: string;
}

const ChatInterface: React.FC = () => {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      type: 'assistant',
      content: "Hello! I'm Luna, your AI assistant. How can I help you today?",
      timestamp: new Date(),
      emotion: 'friendly'
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [personality, setPersonality] = useState('loyal');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!message.trim() || isLoading) return;

    const userMessage: Message = {
      id: messages.length + 1,
      type: 'user',
      content: message,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setMessage('');
    setIsLoading(true);

    try {
      // Detect user emotion
      const userEmotion = await openAIService.detectEmotion(message);
      
      // Prepare conversation history for context
      const conversationHistory = messages.slice(-5).map(msg => ({
        role: msg.type === 'user' ? 'user' as const : 'assistant' as const,
        content: msg.content
      }));

      // Add current user message
      conversationHistory.push({
        role: 'user',
        content: message
      });

      // Generate AI response
      const aiResponse = await openAIService.generateChatResponse(
        conversationHistory,
        personality,
        0.8
      );

      // Determine AI emotion based on response content
      const aiEmotion = await openAIService.detectEmotion(aiResponse);

      const assistantMessage: Message = {
        id: messages.length + 2,
        type: 'assistant',
        content: aiResponse,
        timestamp: new Date(),
        emotion: aiEmotion
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error generating response:', error);
      const errorMessage: Message = {
        id: messages.length + 2,
        type: 'assistant',
        content: "I apologize, but I'm having trouble connecting right now. Please try again in a moment.",
        timestamp: new Date(),
        emotion: 'apologetic'
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickMessage = (quickMsg: string) => {
    setMessage(quickMsg);
  };

  const getEmotionIcon = (emotion: string) => {
    switch (emotion) {
      case 'friendly':
      case 'happy':
        return <Heart className="w-4 h-4 text-pink-400" />;
      case 'helpful':
      case 'calm':
        return <Brain className="w-4 h-4 text-blue-400" />;
      case 'supportive':
      case 'excited':
        return <Sparkles className="w-4 h-4 text-purple-400" />;
      default:
        return <Heart className="w-4 h-4 text-gray-400" />;
    }
  };

  const getEmotionColor = (emotion: string) => {
    switch (emotion) {
      case 'happy':
      case 'excited':
        return 'text-yellow-400';
      case 'calm':
      case 'helpful':
        return 'text-blue-400';
      case 'supportive':
      case 'friendly':
        return 'text-purple-400';
      case 'sad':
        return 'text-blue-300';
      case 'angry':
      case 'frustrated':
        return 'text-red-400';
      default:
        return 'text-gray-400';
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-full flex flex-col">
      {/* Header */}
      <div className="bg-white/5 backdrop-blur-lg rounded-t-xl p-6 border border-white/10 border-b-0">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Chat with Luna</h1>
            <p className="text-gray-400">Multi-language AI conversation with emotional intelligence</p>
          </div>
          <div className="flex items-center space-x-2">
            <select
              value={personality}
              onChange={(e) => setPersonality(e.target.value)}
              className="bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-purple-400"
            >
              <option value="loyal">Loyal Mode</option>
              <option value="seductive">Seductive Mode</option>
              <option value="neutral">Neutral Mode</option>
            </select>
          </div>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 bg-white/5 backdrop-blur-lg border-x border-white/10 p-6 overflow-y-auto space-y-4 max-h-96">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                msg.type === 'user'
                  ? 'bg-purple-500 text-white'
                  : 'bg-white/10 text-gray-100 border border-white/20'
              }`}
            >
              {msg.type === 'assistant' && msg.emotion && (
                <div className="flex items-center space-x-2 mb-2">
                  {getEmotionIcon(msg.emotion)}
                  <span className={`text-xs capitalize ${getEmotionColor(msg.emotion)}`}>
                    {msg.emotion}
                  </span>
                </div>
              )}
              <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
              <span className="text-xs opacity-70 mt-2 block">
                {msg.timestamp.toLocaleTimeString()}
              </span>
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white/10 text-gray-100 border border-white/20 px-4 py-3 rounded-lg">
              <div className="flex items-center space-x-2">
                <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
                <span className="text-sm">Luna is thinking...</span>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="bg-white/5 backdrop-blur-lg rounded-b-xl p-6 border border-white/10 border-t-0">
        <div className="flex space-x-4">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
            placeholder="Type your message to Luna..."
            disabled={isLoading}
            className="flex-1 bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 disabled:opacity-50"
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !message.trim()}
            className="bg-purple-500 hover:bg-purple-600 disabled:bg-gray-500 disabled:cursor-not-allowed text-white p-3 rounded-lg transition-colors duration-200"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </button>
        </div>
        
        {/* Quick Responses */}
        <div className="flex flex-wrap gap-2 mt-4">
          {[
            "What's the weather like?",
            "Tell me about yourself",
            "Help me with a task",
            "What can you do?",
            "Tell me a joke",
            "How are you feeling?"
          ].map((quickMsg) => (
            <button
              key={quickMsg}
              onClick={() => handleQuickMessage(quickMsg)}
              disabled={isLoading}
              className="bg-white/10 hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed text-gray-300 px-3 py-1 rounded-full text-sm transition-colors duration-200"
            >
              {quickMsg}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;