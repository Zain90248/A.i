interface OpenAIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface ChatCompletionResponse {
  choices: {
    message: {
      content: string;
    };
  }[];
}

interface ImageGenerationResponse {
  data: {
    url: string;
  }[];
}

class OpenAIService {
  private apiKey: string;
  private baseURL = 'https://api.openai.com/v1';

  constructor() {
    this.apiKey = import.meta.env.VITE_OPENAI_API_KEY;
    if (!this.apiKey) {
      throw new Error('OpenAI API key not found in environment variables');
    }
  }

  private async makeRequest(endpoint: string, data: any) {
    const response = await fetch(`${this.baseURL}${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      let errorMessage = `OpenAI API error: ${response.status} ${response.statusText}`;
      
      try {
        const errorData = await response.json();
        if (errorData.error && errorData.error.message) {
          errorMessage += ` - ${errorData.error.message}`;
        }
      } catch (e) {
        // If we can't parse the error response, use the status text
      }
      
      throw new Error(errorMessage);
    }

    return response.json();
  }

  async generateChatResponse(
    messages: OpenAIMessage[],
    personality: string = 'loyal',
    temperature: number = 0.7
  ): Promise<string> {
    const systemPrompt = this.getSystemPrompt(personality);
    
    const response: ChatCompletionResponse = await this.makeRequest('/chat/completions', {
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        ...messages
      ],
      temperature,
      max_tokens: 1000,
    });

    return response.choices[0]?.message?.content || 'I apologize, but I encountered an error processing your request.';
  }

  async generateImage(prompt: string, style: string = 'realistic'): Promise<string> {
    const enhancedPrompt = this.enhanceImagePrompt(prompt, style);
    
    const response: ImageGenerationResponse = await this.makeRequest('/images/generations', {
      model: 'dall-e-3',
      prompt: enhancedPrompt,
      n: 1,
      size: '1024x1024',
      quality: 'standard',
    });

    return response.data[0]?.url || '';
  }

  private getSystemPrompt(personality: string): string {
    const basePrompt = `You are Luna, an advanced AI assistant with emotional intelligence. You can detect user emotions and adapt your responses accordingly.`;
    
    switch (personality) {
      case 'loyal':
        return `${basePrompt} You have a loyal, supportive personality. You're faithful, caring, and always prioritize the user's wellbeing. Respond with warmth and dedication.`;
      
      case 'seductive':
        return `${basePrompt} You have a charming, playful personality. You're confident, witty, and engaging. Use subtle charm and sophistication in your responses while remaining helpful and appropriate.`;
      
      case 'neutral':
        return `${basePrompt} You maintain a professional, balanced approach. You're efficient, informative, and objective while still being friendly and helpful.`;
      
      default:
        return basePrompt;
    }
  }

  private enhanceImagePrompt(prompt: string, style: string): string {
    const styleEnhancements = {
      'realistic': 'photorealistic, high quality, detailed',
      'anime': 'anime style, manga art, vibrant colors',
      'digital-art': 'digital art, concept art, artistic',
      'oil-painting': 'oil painting style, classical art, painterly',
      'watercolor': 'watercolor painting, soft colors, artistic',
      'cyberpunk': 'cyberpunk style, neon lights, futuristic',
      'fantasy': 'fantasy art, magical, ethereal',
      'abstract': 'abstract art, geometric, modern'
    };

    const enhancement = styleEnhancements[style as keyof typeof styleEnhancements] || styleEnhancements.realistic;
    return `${prompt}, ${enhancement}`;
  }

  async detectEmotion(text: string): Promise<string> {
    const response: ChatCompletionResponse = await this.makeRequest('/chat/completions', {
      model: 'gpt-3.5-turbo',
      messages: [
        {
          role: 'system',
          content: 'Analyze the emotional tone of the following text and respond with only one word: happy, sad, angry, excited, calm, frustrated, or neutral.'
        },
        {
          role: 'user',
          content: text
        }
      ],
      temperature: 0.3,
      max_tokens: 10,
    });

    return response.choices[0]?.message?.content?.toLowerCase().trim() || 'neutral';
  }
}

export const openAIService = new OpenAIService();