# Linux/macOS
export OPENAI_API_KEY="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"

# Windows (PowerShell)
$env:OPENAI_API_KEY = "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"