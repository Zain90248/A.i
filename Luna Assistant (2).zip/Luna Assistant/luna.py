import openai
import requests
DEEPSEEK_API_KEY = "sk-62d7cd1403624e658c67673ae134c03a"
DEEPSEEK_API_URL = "https://platform.deepseek.com/api_keys"
def chat_with_luna(prompt):
    global OWNER_MOOD
    try:
        lang = detect_language(prompt)
        OWNER_MOOD = detect_emotion(prompt)
        personality = get_personality(OWNER_MOOD)

        expert_instruction = (
            "You are Luna, a master-level AI with deep knowledge in all human fields. "
            f"Reply in the language: {lang}."
        )

        headers = {
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
            "Content-Type": "application/json"
        }

        data = {
            "model": "deepseek-chat",  # Use the actual model name from DeepSeek
            "messages": [
                {"role": "system", "content": f"{personality} {expert_instruction}"},
                {"role": "user", "content": prompt}
            ]
        }

        response = requests.post(DEEPSEEK_API_URL, headers=headers, json=data)
        response_data = response.json()

        return response_data['choices'][0]['message']['content'].strip()

    except Exception as e:
        print("Error:", e)
        return "Sorry, I encountered an error while using DeepSeek."
    
    print(chat_with_luna("What's the capital of France?"))
