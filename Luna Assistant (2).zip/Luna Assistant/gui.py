import tkinter as tk
from tkinter import messagebox
import speech_recognition as sr
import pyttsx3
import threading
import requests  # for DeepSeek API

# Initialize TTS engine
engine = pyttsx3.init()

def speak(text):
    engine.say(text)
    engine.runAndWait()

# Dummy DeepSeek call (replace with your real API logic)
def ask_deepseek(question):
    # TODO: Add actual DeepSeek API request here
    return f"You asked: {question}. (This is a dummy response.)"

# Voice input function
def listen():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        speak("Listening...")
        audio = recognizer.listen(source)
    try:
        query = recognizer.recognize_google(audio)
        response = ask_deepseek(query)
        speak(response)
        text_output.config(text=response)
    except Exception as e:
        speak("Sorry, I didn't catch that.")
        text_output.config(text="Error: " + str(e))

# GUI Functionality
def on_mic_click():
    threading.Thread(target=listen).start()

# GUI Setup
root = tk.Tk()
root.title("Luna Assistant")
root.geometry("400x300")
root.configure(bg="#1e1e1e")

title = tk.Label(root, text="🪐 Luna", font=("Helvetica", 24), fg="white", bg="#1e1e1e")
title.pack(pady=10)

mic_button = tk.Button(root, text="🎙️ Speak", font=("Helvetica", 16), command=on_mic_click)
mic_button.pack(pady=20)

text_output = tk.Label(root, text="", font=("Helvetica", 12), fg="white", bg="#1e1e1e", wraplength=350)
text_output.pack(pady=10)

root.mainloop()
